PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/twrp_fogona.mk

COMMON_LUNCH_CHOICES := \
    twrp_fogona-user \
    twrp_fogona-userdebug \
    twrp_fogona-eng
